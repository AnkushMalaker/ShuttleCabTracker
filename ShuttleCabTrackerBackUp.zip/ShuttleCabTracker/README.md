This is an APP that is made to make the lives of VITIANS easier by allowing them to find when and where the shuttle cabs are coming.
This reduces the amount of time they have to spend anywhere for waiting for cabs.
The student/teacher/staff can decide if he or she should start walking or wait for the cab depending on where the cabs are
This also tells if there is space available to sit in the cab using RFID sensors.