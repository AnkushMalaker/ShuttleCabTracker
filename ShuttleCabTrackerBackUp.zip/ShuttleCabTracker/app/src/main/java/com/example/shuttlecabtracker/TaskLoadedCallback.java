package com.example.shuttlecabtracker;


public interface TaskLoadedCallback {
    void onTaskDone(Object... values);
}
